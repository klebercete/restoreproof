# Changelog

All notable changes to RestoreProof are documented here.
Format: [Keep a Changelog](https://keepachangelog.com/), versioning: SemVer.

## [0.2.1] — 2026-11-08

### Fixed
- `--max-entry-mb` values that would overflow on the byte shift are rejected
  with usage exit `2`, including the exact boundary `8796093022208`; nothing
  silently falls back to the 2 GB default.
- Fixed a `maxEntry+1` overflow in the streaming copy when the budget is
  `math.MaxInt64`; the exact-fit check now probes one extra byte.
- Zip entries whose names Windows cannot restore as ordinary files are
  reported corrupt: bare DOS device names (`NUL`, `CON`, `COM1`..., `LPT1`...),
  NTFS alternate data streams (`name:stream`) and components ending in a dot
  or a space. Device-like names with a real extension (`con.txt`) pass the
  path rules; if the filesystem refuses to create them, the entry is then
  reported corrupt through the normal extraction failure.
- Extracted files are created with `O_EXCL` and `0600`, and a destination
  that is a symlink is refused; over-limit partial files are removed.
- A failed temp-directory cleanup is no longer silent: the manifest marks it
  as `cleanup_failed`, the HTML report shows a clean-up warning and the
  console prints one, so "checked" is never claimed for data left on disk.
- Unknown positional arguments now exit `2` with a usage message instead of
  being silently ignored.
- The batch report folder is created before verification starts, so a bad
  `--out` path cannot waste a long batch run.
- Batch reports are claimed case-insensitively, so `Daily.zip` and
  `daily.zip` (possible on case-aware shares) cannot overwrite each other's
  report.

### Added
- The user manual (`Manual-RestoreProof.pdf`) ships inside both
  distribution ZIPs.
- Total budgets: 20 GiB and 1,000,000 entries per archive so a zip bomb
  cannot burn unbounded time or disk. Extracted files are deleted right
  after hashing, so peak temp usage is the largest entry, not the sum.

## [0.2.0] — 2026-11-07

### Added
- Batch mode (`--dir`) in the Pro edition: verifies every `.zip` in a folder,
  writes one report per backup plus a `summary.html`, and keeps going when one
  archive is unreadable.
- Aggregate batch exit code: any corrupt or unreadable archive gives `1`,
  otherwise zero-byte findings or an inconclusive archive give `3`.
- `--version` flag, reporting the build version and edition.
- Per-edition builds: `verify.exe` (Free) and `verify-pro.exe` (Pro), with the
  edition compiled in rather than toggled by a flag.

### Changed
- Default single-backup report is now `report.html`.
- All user-facing strings (CLI, reports, verdicts, errors) are in English.
- Batch reports are named `<backup>-report.html`; `summary.html` stays reserved
  for the batch summary.
- `--manifest` is rejected together with `--dir`.
- Pro reports no longer carry the Free footer watermark.

### Known limits
- ZIP only (no TAR, RAR, 7z or proprietary backup formats).
- Batch mode reads one folder, not a recursive tree.
- No run history: every run writes reports to disk and exits.

## [0.1.0] — 2026-11-07

### Added
- `verify` CLI for ZIP backups with `--backup`, `--out`, `--manifest` and
  `--max-entry-mb`.
- Isolated extraction with zip-slip protection (relative, absolute and
  drive-letter entries rejected).
- Per-file SHA-256 hashing and JSON manifest export.
- One-page printable HTML report with `RESTORABLE` / `CORRUPT` /
  `INCONCLUSIVE` verdict.
- Zero-byte file detection reported as findings.
- Exit codes: `0` ok, `1` corrupt/error, `2` usage, `3` findings.
- Free edition watermark in the report footer.
